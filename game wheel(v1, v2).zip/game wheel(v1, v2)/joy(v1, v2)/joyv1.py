import serial
import time
import pyvjoy

# Налаштування порту
ser = serial.Serial('COM4', 9600)  # Замініть 'COM8' на ваш реальний COM порт
joystick = pyvjoy.VJoyDevice(1)  # Використовуйте перший віртуальний контролер vJoy

while True:
    if ser.in_waiting:
        line = ser.readline().decode('utf-8', errors='ignore').strip()
        data = line.split(',')

        try:
            # Зчитування значень X, Y, Z і кнопок
            xValue = int(data[0].split(':')[1])
            yValue = int(data[1].split(':')[1])
            zValue = int(data[2].split(':')[1])
           # sliderValue = int(data[3].split(':')[1])
            button1 = int(data[4].split(':')[1])
            button2 = int(data[5].split(':')[1])
            button3 = int(data[6].split(':')[1])
            
            # Нормалізація значень X, Y і Z
            xValue = int((xValue / 1023) * 32767)  # Нормалізація до діапазону vJoy
            yValue = int((yValue / 1023) * 32767)
           # zValue = int((zValue / 1023) * 32767)
           # sliderValue = int((zValue / 1023) * 32767)
            
            # Встановлення значень в vJoy
            joystick.set_axis(pyvjoy.HID_USAGE_X, xValue)
            joystick.set_axis(pyvjoy.HID_USAGE_Y, yValue)
            joystick.set_axis(pyvjoy.HID_USAGE_Z, zValue)
            #joystick.set_axis(pyvjoy.HID_USAGE_SL0, sliderValue)
            
            # Встановлення кнопок
            joystick.set_button(1, button1)  # Кнопка 1
            joystick.set_button(2, button2)  # Кнопка 2
            joystick.set_button(3, button3)  # Кнопка 3

        except (IndexError, ValueError) as e:
            print("Помилка обробки даних:", e)
