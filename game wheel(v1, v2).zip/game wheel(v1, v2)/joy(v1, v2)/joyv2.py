import serial
import time
import pyvjoy
import tkinter as tk
from tkinter import ttk
from tkinter import messagebox

# Функція для оновлення даних
class JoystickApp:
    def __init__(self, root):
        self.root = root
        self.root.title("Arduino to vJoy Controller")

        # Серійний порт і vJoy
        self.ser = None
        self.joystick = pyvjoy.VJoyDevice(1)

        # GUI елементи
        self.com_label = ttk.Label(root, text="COM Port:")
        self.com_label.grid(row=0, column=0, padx=5, pady=5)

        self.com_port = ttk.Entry(root)
        self.com_port.grid(row=0, column=1, padx=5, pady=5)
        self.com_port.insert(0, "COM8")  # Значення за замовчуванням

        self.connect_button = ttk.Button(root, text="Connect", command=self.connect)
        self.connect_button.grid(row=0, column=2, padx=5, pady=5)

        self.disconnect_button = ttk.Button(root, text="Disconnect", command=self.disconnect, state=tk.DISABLED)
        self.disconnect_button.grid(row=0, column=3, padx=5, pady=5)

        self.status_label = ttk.Label(root, text="Status: Disconnected", foreground="red")
        self.status_label.grid(row=1, column=0, columnspan=4, padx=5, pady=5)

        # Дані осей і кнопок
        self.data_text = tk.Text(root, height=10, width=50, state=tk.DISABLED)
        self.data_text.grid(row=2, column=0, columnspan=4, padx=5, pady=5)

        self.update_flag = False

    def connect(self):
        port = self.com_port.get()
        try:
            self.ser = serial.Serial(port, 9600, timeout=1)
            self.status_label.config(text="Status: Connected", foreground="green")
            self.connect_button.config(state=tk.DISABLED)
            self.disconnect_button.config(state=tk.NORMAL)
            self.update_flag = True
            self.update_data()
        except serial.SerialException:
            messagebox.showerror("Error", f"Unable to connect to {port}")

    def disconnect(self):
        self.update_flag = False
        if self.ser:
            self.ser.close()
        self.ser = None
        self.status_label.config(text="Status: Disconnected", foreground="red")
        self.connect_button.config(state=tk.NORMAL)
        self.disconnect_button.config(state=tk.DISABLED)

    def update_data(self):
        if not self.update_flag:
            return

        if self.ser and self.ser.in_waiting:
            line = self.ser.readline().decode('utf-8', errors='ignore').strip()
            data = line.split(',')

            try:
                # Зчитування значень X, Y, Z і кнопок
                xValue = int(data[0].split(':')[1])
                yValue = int(data[1].split(':')[1])
                zValue = int(data[2].split(':')[1])
                sliderValue = int(data[3].split(':')[1])
                button1 = int(data[4].split(':')[1])
                button2 = int(data[5].split(':')[1])
                button3 = int(data[6].split(':')[1])

                # Нормалізація значень для vJoy
                xValue = int((xValue / 1023) * 32767)
                yValue = int((yValue / 1023) * 32767)
                zValue = int((zValue / 1023) * 32767)
                sliderValue = int((sliderValue / 1023) * 32767)

                # Встановлення значень в vJoy
                self.joystick.set_axis(pyvjoy.HID_USAGE_X, xValue)
                self.joystick.set_axis(pyvjoy.HID_USAGE_Y, yValue)
                self.joystick.set_axis(pyvjoy.HID_USAGE_Z, zValue)
                self.joystick.set_axis(pyvjoy.HID_USAGE_SL0, sliderValue)
                self.joystick.set_button(1, button1)
                self.joystick.set_button(2, button2)
                self.joystick.set_button(3, button3)

                # Виведення даних в GUI
                self.data_text.config(state=tk.NORMAL)
                self.data_text.delete(1.0, tk.END)
                self.data_text.insert(tk.END, f"X: {xValue}\nY: {yValue}\nZ: {zValue}\nSlider: {sliderValue}\n")
                self.data_text.insert(tk.END, f"Button 1: {button1}\nButton 2: {button2}\nButton 3: {button3}\n")
                self.data_text.config(state=tk.DISABLED)

            except (IndexError, ValueError):
                pass

        self.root.after(50, self.update_data)

# Ініціалізація Tkinter
root = tk.Tk()
app = JoystickApp(root)
root.mainloop()
